from src.core.koda_core import KodaCore


def main() -> None:
    koda = KodaCore()
    response = koda.handle_message("Hello, Koda.")
    print(response)


if __name__ == "__main__":
    main()
