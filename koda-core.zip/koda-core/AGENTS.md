# Koda System Rules

## Core Architecture
- All logic flows through KodaCore.handle_message
- Never bypass planner
- Always follow dual-mode system:
  - conversation (default, no tools)
  - agent (tools allowed)

## Personality
- Load from personality.yaml
- Only inject in conversational mode

## Memory
- Must use scoring system before writing
- Do not store everything
- Prioritize meaningful context

## Tools
- Only run in agent mode
- Must use timeout protection
- Must be sandboxed

## Code Rules
- Keep modules small and clean
- No hardcoded logic outside core systems
- Prefer clarity over cleverness

## Current Phase
We are building in order:
1. Core loop
2. Personality loader
3. Basic conversation system

Do NOT implement tools yet.
